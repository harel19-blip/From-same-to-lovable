# Maritime Operations - Site Architecture

## 1. FULL SITE MAP & NAVIGATION

### Main Navigation
```
├── Home
├── About Us
│   ├── Company Overview
│   ├── Founder
│   ├── Vision & Mission
│   └── Values & Principles
├── Services
│   ├── Maritime Operations
│   ├── Rescue & Emergency Response
│   ├── Environmental Missions
│   ├── Technology Solutions
│   └── Crew Assembly
├── Missions (Projects)
├── Sectors (Markets)
│   ├── Offshore & Maritime
│   ├── Environmental & Sustainability
│   ├── Rescue & Emergency
│   └── Research & Technology
├── Careers
│   ├── Who We Seek
│   ├── Working With Us
│   └── Apply Now
├── Insights (News)
└── Contact
```

### Header Navigation
- Logo (left)
- Main nav items (center/left)
- Language switcher EN/HE (right)
- Contact CTA button (right)

### Footer Navigation
```
├── Quick Links
│   ├── About Us
│   ├── Services
│   ├── Missions
│   ├── Careers
│   └── Contact
├── Stay Connected
│   ├── Latest News
│   └── LinkedIn
├── Legal
│   ├── Privacy Policy
│   ├── Terms of Service
│   └── Cookie Policy
└── Language Switcher
```

---

## 2. PAGE-BY-PAGE STRUCTURE

### HOME PAGE

#### Section 1: Hero [CORE]
- Full-viewport video background (placeholder)
- Company tagline (authoritative, mission-focused)
- Primary CTA: "Explore Our Capabilities"
- Secondary CTA: "Join Our Teams"

#### Section 2: Mission Statement [CORE]
- Short, authoritative company statement
- 3-4 key statistics (operations count, global reach, etc.)

#### Section 3: Core Capabilities [CORE]
- 5 modular capability blocks:
  1. Maritime Operations
  2. Rescue & Emergency Response
  3. Environmental Missions
  4. Technology Solutions
  5. Crew Assembly & Planning

#### Section 4: Operational Approach [CORE]
- "How We Work" - 4 steps:
  1. Assessment & Planning
  2. Team Assembly
  3. Mission Execution
  4. Outcome & Debrief

#### Section 5: Mission Types [CORE]
- Grid of sectors/industries served
- Link to each sector page

#### Section 6: Featured Missions [OPTIONAL]
- 3 featured mission cards
- Environment type, role, outcome

#### Section 7: Founder Highlight [CORE]
- Single founder profile
- Leadership message
- Trust-building credentials

#### Section 8: Dual CTA [CORE]
- Split section:
  - Left: Contact for business inquiries
  - Right: Join our professional team

---

### ABOUT US PAGE

#### Section 1: Page Hero [CORE]
- Title: "Who We Are"
- Brief intro paragraph

#### Section 2: Company Overview [CORE]
- History and establishment
- International operations scope
- Core competencies summary

#### Section 3: Founder Profile [CORE]
- Photo placeholder
- Background and credentials
- Leadership philosophy
- Trust-building statement

#### Section 4: Vision & Mission [CORE]
- Vision statement
- Mission statement
- Clear, concise, authoritative

#### Section 5: Values & Principles [CORE]
- Safety First
- Operational Excellence
- Environmental Responsibility
- Professional Integrity
- Mission Commitment

#### Section 6: Safety & Ethics [CORE]
- Safety commitment
- Ethical standards
- Compliance statement

#### Section 7: International Presence [OPTIONAL]
- Operational regions
- Global capabilities

---

### SERVICES PAGE

#### Section 1: Page Hero [CORE]
- Title: "Our Capabilities"
- Overview of service range

#### Section 2: Service Categories [CORE]

##### Maritime Operations
- Complex offshore operations
- Vessel support
- Marine logistics
- Capability highlights

##### Rescue & Emergency Response
- Open-sea rescue
- Emergency response
- Crisis management
- Rapid deployment

##### Environmental Missions
- Ocean protection
- Environmental monitoring
- Cleanup operations
- Sustainability projects

##### Technology Solutions
- Hybrid maritime-tech missions
- Advanced monitoring
- Innovation integration

##### Crew Assembly
- Mission-specific teams
- Professional vetting
- Specialized expertise

---

### MISSIONS PAGE

#### Section 1: Page Hero [CORE]
- Title: "Our Missions"
- Mission-focused intro

#### Section 2: Mission Grid [CORE]
- Filterable grid
- Each mission card includes:
  - Mission type
  - Environment (offshore/open-sea/coastal)
  - Company role
  - Outcome summary
  - Image placeholder

---

### SECTORS PAGE

#### Section 1: Page Hero [CORE]
- Title: "Markets We Serve"

#### Section 2: Sector Grid [CORE]
- Offshore & Maritime
- Environmental & Sustainability
- Rescue & Emergency
- Research & Technology

---

### CAREERS PAGE

#### Section 1: Page Hero [CORE]
- Title: "Join Our Team"
- Professional, recruitment-focused

#### Section 2: Who We Seek [CORE]
- Professional profiles
- Experience requirements
- Character traits

#### Section 3: Expectations [CORE]
- Performance standards
- Safety commitment
- Team collaboration

#### Section 4: Mission Types [CORE]
- Types of assignments
- Duration and locations
- Working conditions

#### Section 5: Environment [OPTIONAL]
- Team culture
- Professional development
- Equipment and support

#### Section 6: Process [CORE]
- Application steps
- Vetting process
- Onboarding

#### Section 7: Apply CTA [CORE]
- CV submission form
- Contact information

---

### NEWS & INSIGHTS PAGE

#### Section 1: Page Hero [CORE]
- Title: "News & Insights"

#### Section 2: News Grid [CORE]
- Industry news
- Company updates
- Thought leadership
- Press releases

---

### CONTACT PAGE

#### Section 1: Page Hero [CORE]
- Title: "Contact Us"

#### Section 2: Contact Form [CORE]
- Name
- Email
- Organization
- Inquiry type
- Message

#### Section 3: Contact Information [CORE]
- Business email
- LinkedIn
- Address

---

## 3. REMOVED SECTIONS (vs Boskalis)
- Investor relations / financials
- Stock information
- Multi-subsidiary structure
- Download center for reports
- Complex governance structure
- Multiple board members
- Fleet inventory details

## 4. ADDED SECTIONS (for target company)
- Single founder prominence
- Recruitment emphasis
- Mission-based storytelling
- Trust and credibility focus
- Bilingual support structure
- Simplified navigation
- Clear dual-track (clients/recruits)

---

## 5. DESIGN TOKENS

### Colors
- Primary: Navy (#0f172a)
- Secondary: Slate (#334155)
- Accent: Neutral warm (#a8a29e)
- Background: White (#ffffff)
- Background Alt: Light gray (#f8fafc)
- Text Primary: Charcoal (#1e293b)
- Text Secondary: Slate (#64748b)

### Typography
- Headings: Inter, system-ui (clean, professional)
- Body: Inter, system-ui
- Display sizes for hero sections

### Spacing
- Section padding: 80px-120px vertical
- Container max-width: 1280px
- Grid gaps: 24px-48px
