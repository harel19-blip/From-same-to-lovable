import { Metadata } from "next";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Shield,
  Target,
  TreePine,
  HandHeart,
  Compass,
  Quote,
  ChevronRight,
  Globe2,
  Award,
  Users,
} from "lucide-react";

export const metadata: Metadata = {
  title: "About Us | Maritime Operations",
  description:
    "Learn about our company, founder, vision, and the values that drive our maritime operations worldwide.",
};

const values = [
  {
    icon: Shield,
    title: "Safety First",
    description:
      "Every decision prioritizes the safety of our teams, clients, and the environments we operate in. No mission objective justifies compromising safety.",
  },
  {
    icon: Target,
    title: "Operational Excellence",
    description:
      "We execute with precision, efficiency, and professionalism. Our standards are non-negotiable, and our performance is measured by outcomes.",
  },
  {
    icon: TreePine,
    title: "Environmental Responsibility",
    description:
      "We protect the marine environments where we operate. Sustainability and conservation are integral to our mission approach.",
  },
  {
    icon: HandHeart,
    title: "Professional Integrity",
    description:
      "Honesty, transparency, and accountability define our relationships with clients, partners, and team members.",
  },
  {
    icon: Compass,
    title: "Mission Commitment",
    description:
      "When we accept a mission, we see it through. Our reliability and determination are the foundation of client trust.",
  },
];

const milestones = [
  { year: "Founded", description: "Company established with core mission focus" },
  { year: "Year 2", description: "First international rescue operation" },
  { year: "Year 5", description: "Expanded to 20+ countries of operation" },
  { year: "Present", description: "500+ missions completed worldwide" },
];

export default function AboutPage() {
  return (
    <>
      {/* PAGE HERO [CORE] */}
      <section className="relative bg-navy py-20 lg:py-28">
        <div className="absolute inset-0 bg-gradient-to-br from-navy via-navy-light to-navy opacity-90" />
        <div className="container-wide relative">
          <div className="max-w-3xl">
            <div className="w-16 h-1 bg-stone-400 mb-8" />
            <h1 className="text-white mb-6">Who We Are</h1>
            <p className="text-xl text-slate-300 leading-relaxed">
              A private, founder-led maritime services company operating
              internationally. We specialize in high-stakes operations where
              safety, precision, and professionalism are non-negotiable.
            </p>
          </div>
        </div>
      </section>

      {/* COMPANY OVERVIEW [CORE] */}
      <section className="section-padding bg-white">
        <div className="container-wide">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <div>
              <div className="accent-line" />
              <h2 className="text-navy mb-6">Company Overview</h2>
              <div className="space-y-4 text-slate-600 leading-relaxed">
                <p>
                  We are an international maritime services company, privately
                  held and founder-led. Our operations span the globe, from the
                  North Atlantic to the Pacific, from coastal waters to open
                  sea environments.
                </p>
                <p>
                  Our core specializations include open-sea rescue missions,
                  complex offshore operations, environmental protection projects,
                  and technology-integrated maritime solutions. We assemble
                  mission-specific crews from a network of vetted professionals
                  with specialized expertise.
                </p>
                <p>
                  Unlike large corporate contractors, we maintain the agility,
                  accountability, and personal commitment that comes with
                  founder-led operations. Every mission carries our direct
                  responsibility and attention.
                </p>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 gap-6">
              <Card className="bg-slate-50 border-0">
                <CardContent className="p-6 text-center">
                  <Globe2 className="w-8 h-8 text-navy mx-auto mb-3" />
                  <div className="text-3xl font-semibold text-navy mb-1">40+</div>
                  <div className="text-sm text-slate-600">Countries of Operation</div>
                </CardContent>
              </Card>
              <Card className="bg-slate-50 border-0">
                <CardContent className="p-6 text-center">
                  <Award className="w-8 h-8 text-navy mx-auto mb-3" />
                  <div className="text-3xl font-semibold text-navy mb-1">500+</div>
                  <div className="text-sm text-slate-600">Missions Completed</div>
                </CardContent>
              </Card>
              <Card className="bg-slate-50 border-0">
                <CardContent className="p-6 text-center">
                  <Users className="w-8 h-8 text-navy mx-auto mb-3" />
                  <div className="text-3xl font-semibold text-navy mb-1">200+</div>
                  <div className="text-sm text-slate-600">Expert Professionals</div>
                </CardContent>
              </Card>
              <Card className="bg-slate-50 border-0">
                <CardContent className="p-6 text-center">
                  <Shield className="w-8 h-8 text-navy mx-auto mb-3" />
                  <div className="text-3xl font-semibold text-navy mb-1">100%</div>
                  <div className="text-sm text-slate-600">Safety Record</div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* FOUNDER PROFILE [CORE] */}
      <section id="founder" className="section-padding bg-slate-50">
        <div className="container-wide">
          <div className="grid lg:grid-cols-5 gap-12 lg:gap-16">
            {/* Image Column */}
            <div className="lg:col-span-2">
              <div className="relative aspect-[3/4] bg-gradient-to-br from-slate-200 to-slate-300 rounded-lg overflow-hidden sticky top-24">
                <div className="absolute inset-0 bg-navy/10" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-32 h-32 rounded-full bg-slate-300/50 flex items-center justify-center">
                    <span className="text-4xl text-slate-500">F</span>
                  </div>
                </div>
                {/* Placeholder label */}
                <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-navy/80 to-transparent">
                  <p className="text-white font-semibold">[Founder Name]</p>
                  <p className="text-slate-300 text-sm">Founder & Director</p>
                </div>
              </div>
            </div>

            {/* Content Column */}
            <div className="lg:col-span-3">
              <div className="accent-line" />
              <h2 className="text-navy mb-6">Our Founder</h2>

              {/* Quote */}
              <div className="relative mb-8 p-6 bg-white rounded-lg">
                <Quote className="absolute top-4 left-4 w-8 h-8 text-slate-200" />
                <blockquote className="text-lg text-slate-700 italic leading-relaxed pl-8">
                  "In maritime operations, there are no second chances. Every
                  decision must be made with the understanding that lives,
                  environments, and critical outcomes depend on our judgment.
                  This responsibility is what drives everything we do."
                </blockquote>
              </div>

              <div className="space-y-4 text-slate-600 leading-relaxed mb-8">
                <p>
                  <strong className="text-navy">[Founder Name]</strong> brings over
                  25 years of direct maritime operations experience to the company.
                  A career spanning naval operations, commercial maritime services,
                  and emergency response has provided the foundation for our
                  company's operational philosophy.
                </p>
                <p>
                  After witnessing firsthand the gaps in professional maritime
                  services—particularly in high-stakes rescue and specialized
                  offshore operations—[Founder Name] established this company
                  to deliver the level of professionalism, safety, and commitment
                  that critical missions demand.
                </p>
                <p>
                  Today, [Founder Name] remains directly involved in mission
                  planning, team assembly, and operational oversight. The
                  founder-led approach ensures accountability and maintains the
                  standards that define our reputation.
                </p>
              </div>

              {/* Credentials */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-4 bg-white rounded-lg border border-slate-200">
                  <div className="text-2xl font-semibold text-navy mb-1">25+</div>
                  <div className="text-sm text-slate-600">Years Experience</div>
                </div>
                <div className="p-4 bg-white rounded-lg border border-slate-200">
                  <div className="text-2xl font-semibold text-navy mb-1">300+</div>
                  <div className="text-sm text-slate-600">Missions Led</div>
                </div>
                <div className="p-4 bg-white rounded-lg border border-slate-200">
                  <div className="text-2xl font-semibold text-navy mb-1">40+</div>
                  <div className="text-sm text-slate-600">Countries Operated</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* VISION & MISSION [CORE] */}
      <section className="section-padding bg-navy">
        <div className="container-wide">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16">
            {/* Vision */}
            <div className="p-8 lg:p-10 bg-white/5 rounded-lg border border-white/10">
              <h3 className="text-xl font-semibold text-white mb-4 uppercase tracking-wider">
                Our Vision
              </h3>
              <p className="text-xl text-slate-300 leading-relaxed">
                To be the trusted partner for the world's most critical maritime
                operations—where reliability, safety, and professional excellence
                are not expectations, but guarantees.
              </p>
            </div>

            {/* Mission */}
            <div className="p-8 lg:p-10 bg-white/5 rounded-lg border border-white/10">
              <h3 className="text-xl font-semibold text-white mb-4 uppercase tracking-wider">
                Our Mission
              </h3>
              <p className="text-xl text-slate-300 leading-relaxed">
                To execute maritime operations with unwavering commitment to safety,
                environmental responsibility, and mission success—assembling the
                right professionals for every unique challenge at sea.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* VALUES & PRINCIPLES [CORE] */}
      <section id="values" className="section-padding bg-white">
        <div className="container-wide">
          <div className="text-center mb-12">
            <div className="accent-line-center" />
            <h2 className="text-navy mb-4">Values & Principles</h2>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
              The principles that guide every operation, every decision, and
              every team member in our organization.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {values.map((value) => (
              <Card key={value.title} className="bg-slate-50 border-0">
                <CardContent className="p-8">
                  <div className="w-12 h-12 bg-navy/10 rounded-lg flex items-center justify-center mb-4">
                    <value.icon className="w-6 h-6 text-navy" />
                  </div>
                  <h4 className="text-lg font-semibold text-navy mb-3">
                    {value.title}
                  </h4>
                  <p className="text-slate-600 leading-relaxed">
                    {value.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* SAFETY & ETHICS [CORE] */}
      <section className="section-padding bg-slate-50">
        <div className="container-wide">
          <div className="max-w-4xl mx-auto text-center">
            <div className="accent-line-center" />
            <h2 className="text-navy mb-6">Safety, Responsibility & Ethics</h2>
            <p className="text-lg text-slate-600 leading-relaxed mb-8">
              Our commitment to safety extends beyond regulatory compliance. We
              maintain rigorous standards for personnel training, equipment
              maintenance, operational protocols, and environmental protection.
              Every team member understands that our reputation—and more
              importantly, lives—depend on unwavering adherence to these standards.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-6 bg-white rounded-lg">
                <h5 className="font-semibold text-navy mb-2">Personnel Safety</h5>
                <p className="text-sm text-slate-600">
                  Comprehensive training, certifications, and continuous
                  professional development for all team members.
                </p>
              </div>
              <div className="p-6 bg-white rounded-lg">
                <h5 className="font-semibold text-navy mb-2">Environmental Compliance</h5>
                <p className="text-sm text-slate-600">
                  Strict adherence to international maritime environmental
                  regulations and best practices.
                </p>
              </div>
              <div className="p-6 bg-white rounded-lg">
                <h5 className="font-semibold text-navy mb-2">Ethical Operations</h5>
                <p className="text-sm text-slate-600">
                  Transparency, accountability, and integrity in all business
                  relationships and operations.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section-padding bg-navy">
        <div className="container-wide text-center">
          <h2 className="text-white mb-6">Ready to Work Together?</h2>
          <p className="text-slate-300 mb-8 max-w-2xl mx-auto">
            Whether you need maritime services or are seeking to join our
            professional team, we welcome the conversation.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              asChild
              size="lg"
              className="bg-white text-navy hover:bg-slate-100"
            >
              <Link href="/contact">Contact Us</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white/30 text-white hover:bg-white/10"
            >
              <Link href="/careers">
                Join Our Team
                <ChevronRight className="w-4 h-4 ml-1" />
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}
