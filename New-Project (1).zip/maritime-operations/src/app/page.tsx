import { HeroSection } from "@/components/home/HeroSection";
import { MissionStatement } from "@/components/home/MissionStatement";
import { CapabilitiesSection } from "@/components/home/CapabilitiesSection";
import { OperationalApproach } from "@/components/home/OperationalApproach";
import { SectorsSection } from "@/components/home/SectorsSection";
import { FeaturedMissions } from "@/components/home/FeaturedMissions";
import { LatestInsights } from "@/components/home/LatestInsights";
import { FounderSection } from "@/components/home/FounderSection";
import { DualCTASection } from "@/components/home/DualCTASection";

export default function HomePage() {
  return (
    <>
      {/* SECTION 1: Hero - Full viewport video background [CORE] */}
      <HeroSection />

      {/* SECTION 2: Mission Statement with Statistics [CORE] */}
      <MissionStatement />

      {/* SECTION 3: Core Capabilities Grid [CORE] */}
      <CapabilitiesSection />

      {/* SECTION 4: Operational Approach - How We Work [CORE] */}
      <OperationalApproach />

      {/* SECTION 5: Sectors/Industries Served [CORE] */}
      <SectorsSection />

      {/* SECTION 6: Featured Missions [OPTIONAL] */}
      <FeaturedMissions />

      {/* SECTION 6.5: Latest Industry News & Insights [NEW] */}
      <LatestInsights />

      {/* SECTION 7: Founder Highlight [CORE] */}
      <FounderSection />

      {/* SECTION 8: Dual CTA - Contact & Careers [CORE] */}
      <DualCTASection />
    </>
  );
}
