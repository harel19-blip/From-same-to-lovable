import { Metadata } from "next";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Mail,
  Phone,
  MapPin,
  Linkedin,
  Clock,
  ArrowRight,
  Shield,
} from "lucide-react";

export const metadata: Metadata = {
  title: "Contact | Maritime Operations",
  description:
    "Contact our team for business inquiries, partnership discussions, or to learn more about our maritime services.",
};

const contactInfo = [
  {
    icon: Mail,
    title: "Email",
    value: "contact@maritime-ops.com",
    href: "mailto:contact@maritime-ops.com",
    description: "For general inquiries",
  },
  {
    icon: Phone,
    title: "Phone",
    value: "+1 (234) 567-890",
    href: "tel:+1234567890",
    description: "Business hours",
  },
  {
    icon: MapPin,
    title: "Address",
    value: "International Operations Center",
    href: null,
    description: "Address available upon request",
  },
  {
    icon: Linkedin,
    title: "LinkedIn",
    value: "Maritime Operations",
    href: "https://linkedin.com",
    description: "Connect with us",
  },
];

export default function ContactPage() {
  return (
    <>
      {/* PAGE HERO [CORE] */}
      <section className="relative bg-navy py-20 lg:py-28">
        <div className="absolute inset-0 bg-gradient-to-br from-navy via-navy-light to-navy opacity-90" />
        <div className="container-wide relative">
          <div className="max-w-3xl">
            <div className="w-16 h-1 bg-stone-400 mb-8" />
            <h1 className="text-white mb-6">Contact Us</h1>
            <p className="text-xl text-slate-300 leading-relaxed">
              Ready to discuss your maritime requirements? Our team responds
              to all inquiries within 24 hours.
            </p>
          </div>
        </div>
      </section>

      {/* CONTACT SECTION [CORE] */}
      <section className="section-padding bg-white">
        <div className="container-wide">
          <div className="grid lg:grid-cols-5 gap-12 lg:gap-16">
            {/* Contact Form */}
            <div className="lg:col-span-3">
              <div className="accent-line" />
              <h2 className="text-navy mb-6">Send Us a Message</h2>

              <Card className="bg-slate-50 border-0">
                <CardContent className="p-8">
                  <form className="space-y-6">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="firstName">First Name *</Label>
                        <Input
                          id="firstName"
                          placeholder="Your first name"
                          required
                          className="bg-white border-slate-200"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="lastName">Last Name *</Label>
                        <Input
                          id="lastName"
                          placeholder="Your last name"
                          required
                          className="bg-white border-slate-200"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address *</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="your.email@example.com"
                        required
                        className="bg-white border-slate-200"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="organization">Organization</Label>
                      <Input
                        id="organization"
                        placeholder="Your company or organization"
                        className="bg-white border-slate-200"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="inquiryType">Inquiry Type *</Label>
                      <select
                        id="inquiryType"
                        className="w-full h-10 px-3 py-2 text-sm bg-white border border-slate-200 rounded-md focus:outline-none focus:ring-2 focus:ring-navy"
                        required
                      >
                        <option value="">Select inquiry type</option>
                        <option value="services">Maritime Services</option>
                        <option value="rescue">Rescue Operations</option>
                        <option value="environmental">Environmental Missions</option>
                        <option value="partnership">Partnership / Collaboration</option>
                        <option value="careers">Careers / Recruitment</option>
                        <option value="media">Media / Press</option>
                        <option value="other">Other</option>
                      </select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="message">Message *</Label>
                      <Textarea
                        id="message"
                        placeholder="Please describe your inquiry or requirements"
                        required
                        className="bg-white border-slate-200 min-h-[160px]"
                      />
                    </div>

                    <Button
                      type="submit"
                      size="lg"
                      className="w-full bg-navy text-white hover:bg-navy-light"
                    >
                      Send Message
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>

                    <p className="text-xs text-slate-500 text-center">
                      By submitting this form, you agree to our privacy policy.
                      We will respond within 24 business hours.
                    </p>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Contact Information */}
            <div className="lg:col-span-2">
              <div className="accent-line" />
              <h2 className="text-navy mb-6">Contact Information</h2>

              <div className="space-y-6 mb-10">
                {contactInfo.map((item) => (
                  <div key={item.title} className="flex items-start space-x-4">
                    <div className="w-12 h-12 bg-navy/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <item.icon className="w-5 h-5 text-navy" />
                    </div>
                    <div>
                      <h5 className="font-semibold text-navy mb-1">
                        {item.title}
                      </h5>
                      {item.href ? (
                        <a
                          href={item.href}
                          target={item.href.startsWith("http") ? "_blank" : undefined}
                          rel={item.href.startsWith("http") ? "noopener noreferrer" : undefined}
                          className="text-slate-600 hover:text-navy transition-colors"
                        >
                          {item.value}
                        </a>
                      ) : (
                        <p className="text-slate-600">{item.value}</p>
                      )}
                      <p className="text-sm text-slate-500">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Response Time */}
              <Card className="bg-navy text-white border-0">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <Clock className="w-6 h-6 flex-shrink-0" />
                    <div>
                      <h5 className="font-semibold mb-2">Response Time</h5>
                      <p className="text-sm text-slate-300">
                        We respond to all inquiries within 24 business hours.
                        For urgent matters, please indicate urgency in your
                        message or contact us by phone.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Confidentiality Notice */}
              <Card className="bg-slate-50 border-slate-200 mt-6">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <Shield className="w-6 h-6 text-navy flex-shrink-0" />
                    <div>
                      <h5 className="font-semibold text-navy mb-2">
                        Confidentiality
                      </h5>
                      <p className="text-sm text-slate-600">
                        All communications are treated confidentially. We
                        understand the sensitive nature of maritime operations
                        and handle all inquiries with discretion.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* ALTERNATIVE PATHS */}
      <section className="section-padding bg-slate-50">
        <div className="container-wide">
          <div className="grid md:grid-cols-2 gap-8">
            {/* For Clients */}
            <Card className="bg-white border-slate-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <h3 className="text-xl font-semibold text-navy mb-4">
                  For Clients & Partners
                </h3>
                <p className="text-slate-600 mb-6">
                  Looking to discuss maritime service requirements, partnerships,
                  or collaboration opportunities? Our team is ready to understand
                  your needs.
                </p>
                <Button
                  asChild
                  variant="outline"
                  className="border-navy text-navy hover:bg-navy hover:text-white"
                >
                  <Link href="/services">
                    Explore Our Services
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Link>
                </Button>
              </CardContent>
            </Card>

            {/* For Professionals */}
            <Card className="bg-white border-slate-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <h3 className="text-xl font-semibold text-navy mb-4">
                  For Professionals
                </h3>
                <p className="text-slate-600 mb-6">
                  Interested in joining our team? We're always seeking experienced
                  maritime professionals for high-stakes operations worldwide.
                </p>
                <Button
                  asChild
                  variant="outline"
                  className="border-navy text-navy hover:bg-navy hover:text-white"
                >
                  <Link href="/careers">
                    View Career Opportunities
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* MAP PLACEHOLDER */}
      <section className="h-80 bg-gradient-to-br from-slate-200 to-slate-300 flex items-center justify-center">
        <div className="text-center">
          <MapPin className="w-12 h-12 text-slate-400 mx-auto mb-4" />
          <p className="text-slate-500">Map Placeholder</p>
          <p className="text-sm text-slate-400">Interactive map would be integrated here</p>
        </div>
      </section>
    </>
  );
}
