/**
 * Insights/News Data
 * Content for the news and insights sections
 */

import { MEDIA } from "@/lib/constants";

export interface NewsArticle {
  id: string;
  title: string;
  category: string;
  date: string;
  excerpt: string;
  source: string;
  url: string;
  image: string;
}

export const newsArticles: NewsArticle[] = [
  {
    id: "arctic-shipping-2024",
    title: "37% Increase in Arctic Shipping Over Past Decade",
    category: "Maritime Operations",
    date: "January 31, 2024",
    excerpt:
      "The Arctic Council's PAME Working Group reports significant growth in Arctic shipping activity, highlighting new challenges and opportunities for maritime operations in polar regions.",
    source: "Arctic Council",
    url: "https://arctic-council.org/news/increase-in-arctic-shipping/",
    image: MEDIA.images.arctic,
  },
  {
    id: "adriatic-sarex-2024",
    title: "Adriatic Sea SARex-2024 Strengthens International SAR Collaboration",
    category: "Rescue & Emergency",
    date: "October 1, 2024",
    excerpt:
      "Major international search and rescue exercise concludes successfully in the Adriatic Sea, bringing together maritime rescue coordination centers from Croatia, Italy, and Slovenia.",
    source: "EMSA",
    url: "https://www.emsa.europa.eu/newsroom/latest-news/item/5315-adriatic-sea-sarex-2024-concludes-successfully",
    image: MEDIA.images.sarex,
  },
  {
    id: "baltic-maritime-security",
    title: "Multipurpose Maritime Operation Enhances Baltic Sea Security",
    category: "Maritime Operations",
    date: "November 19, 2024",
    excerpt:
      "European maritime operation focuses on enhancing security and cooperation across border control, maritime safety, search and rescue, and environmental protection in the Baltic Sea region.",
    source: "Frontex",
    url: "https://www.frontex.europa.eu/media-centre/news/news-release/wrap-up-of-multipurpose-maritime-operation-baltic-sea-2024",
    image: MEDIA.images.rescue,
  },
  {
    id: "polar-code-operations",
    title: "Polar Code Strengthens Safety in Extreme Maritime Environments",
    category: "Environmental",
    date: "May 15, 2024",
    excerpt:
      "International Maritime Organization's Polar Code continues to set crucial standards for ships operating in Arctic and Antarctic waters, addressing unique environmental and safety challenges.",
    source: "IMO",
    url: "https://www.imo.org/en/ourwork/safety/pages/polar-code.aspx",
    image: MEDIA.images.polar,
  },
  {
    id: "coast-guard-pacific",
    title: "U.S. Coast Guard Strengthens Maritime Safety in Pacific Region",
    category: "Rescue & Emergency",
    date: "September 30, 2024",
    excerpt:
      "Coast Guard delivers comprehensive boating safety workshops and community outreach in Micronesia, spanning search and rescue, law enforcement, and environmental protection operations.",
    source: "U.S. Coast Guard",
    url: "https://www.news.uscg.mil/Press-Releases/Article/3921741/",
    image: MEDIA.images.offshore,
  },
  {
    id: "ocean-conservation-2024",
    title: "Marine Mammal Protection Achievements in Ocean Health",
    category: "Environmental",
    date: "April 23, 2024",
    excerpt:
      "The Marine Mammal Center reports significant progress in ocean health initiatives, including advances in treating domoic acid poisoning and species conservation efforts.",
    source: "Marine Mammal Center",
    url: "https://www.marinemammalcenter.org/news/achievements-in-ocean-health",
    image: MEDIA.images.environmental,
  },
];

export const newsCategories = [
  "All",
  "Maritime Operations",
  "Rescue & Emergency",
  "Environmental",
  "Technology",
];

// Featured insights for homepage
export const featuredInsights = newsArticles.slice(0, 3);
