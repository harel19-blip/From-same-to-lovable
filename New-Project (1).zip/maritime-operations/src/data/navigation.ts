/**
 * Navigation Data
 * Centralized navigation structure for header, footer, and menus
 */

import { ROUTES } from "@/lib/constants";

export interface NavItem {
  translationKey: string;
  href: string;
  submenu?: NavSubmenuItem[];
}

export interface NavSubmenuItem {
  translationKey: string;
  href: string;
  descriptionKey: string;
}

export const mainNavigation: NavItem[] = [
  { translationKey: "nav.home", href: ROUTES.home },
  {
    translationKey: "nav.about",
    href: ROUTES.about,
    submenu: [
      { translationKey: "nav.aboutCompany", href: "/about", descriptionKey: "about.overviewTitle" },
      { translationKey: "nav.aboutFounder", href: "/about#founder", descriptionKey: "founder.role" },
      { translationKey: "nav.aboutValues", href: "/about#values", descriptionKey: "about.valuesTitle" },
    ],
  },
  {
    translationKey: "nav.services",
    href: ROUTES.services,
    submenu: [
      { translationKey: "nav.maritimeOps", href: "/services#maritime", descriptionKey: "capabilities.maritime.title" },
      { translationKey: "nav.rescue", href: "/services#rescue", descriptionKey: "capabilities.rescue.title" },
      { translationKey: "nav.environmental", href: "/services#environmental", descriptionKey: "capabilities.environmental.title" },
      { translationKey: "nav.technology", href: "/services#technology", descriptionKey: "capabilities.technology.title" },
      { translationKey: "nav.crewAssembly", href: "/services#crew", descriptionKey: "capabilities.crew.title" },
    ],
  },
  { translationKey: "nav.missions", href: ROUTES.missions },
  {
    translationKey: "nav.sectors",
    href: ROUTES.sectors,
    submenu: [
      { translationKey: "nav.offshore", href: "/sectors#offshore", descriptionKey: "sectors.offshore.title" },
      { translationKey: "nav.environmentalSector", href: "/sectors#environmental", descriptionKey: "sectors.environmental.title" },
      { translationKey: "nav.rescueSector", href: "/sectors#rescue", descriptionKey: "sectors.rescue.title" },
      { translationKey: "nav.research", href: "/sectors#research", descriptionKey: "sectors.research.title" },
    ],
  },
  { translationKey: "nav.insights", href: ROUTES.insights },
  { translationKey: "nav.workWithUs", href: ROUTES.workWithUs },
];

export const footerLinks = {
  company: [
    { translationKey: "nav.about", href: ROUTES.about },
    { translationKey: "nav.services", href: ROUTES.services },
    { translationKey: "nav.missions", href: ROUTES.missions },
    { translationKey: "nav.sectors", href: ROUTES.sectors },
  ],
  careers: [
    { translationKey: "nav.workWithUs", href: ROUTES.workWithUs },
  ],
  resources: [
    { translationKey: "nav.insights", href: ROUTES.insights },
    { translationKey: "nav.contact", href: ROUTES.contact },
  ],
  legal: [
    { translationKey: "footer.privacy", href: ROUTES.privacy },
    { translationKey: "footer.terms", href: ROUTES.terms },
    { translationKey: "footer.cookies", href: ROUTES.cookies },
  ],
};
