/**
 * Operational Approach Data
 * Content for the "How We Work" section
 */

import { ClipboardCheck, Users2, Target, FileCheck } from "lucide-react";
import type { LucideIcon } from "lucide-react";

export interface ApproachStep {
  number: string;
  icon: LucideIcon;
  titleKey: string;
  descriptionKey: string;
}

export const approachSteps: ApproachStep[] = [
  {
    number: "01",
    icon: ClipboardCheck,
    titleKey: "approach.step1.title",
    descriptionKey: "approach.step1.description",
  },
  {
    number: "02",
    icon: Users2,
    titleKey: "approach.step2.title",
    descriptionKey: "approach.step2.description",
  },
  {
    number: "03",
    icon: Target,
    titleKey: "approach.step3.title",
    descriptionKey: "approach.step3.description",
  },
  {
    number: "04",
    icon: FileCheck,
    titleKey: "approach.step4.title",
    descriptionKey: "approach.step4.description",
  },
];
