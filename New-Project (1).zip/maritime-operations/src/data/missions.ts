/**
 * Missions Data
 * Content for the featured missions section
 */

import { MEDIA } from "@/lib/constants";

export interface Mission {
  id: string;
  title: string;
  type: string;
  environment: string;
  location: string;
  description: string;
  outcome: string;
  image: string;
  href: string;
}

export const featuredMissions: Mission[] = [
  {
    id: "deep-sea-rescue",
    title: "Deep Sea Rescue Operation",
    type: "Rescue & Emergency",
    environment: "Open Sea",
    location: "North Atlantic",
    description:
      "Rapid response rescue operation in severe weather conditions. Successful extraction of crew from distressed vessel.",
    outcome: "All crew recovered safely",
    image: MEDIA.images.deepSeaRescue,
    href: "/missions/deep-sea-rescue",
  },
  {
    id: "offshore-platform",
    title: "Offshore Platform Support",
    type: "Maritime Operations",
    environment: "Offshore",
    location: "Mediterranean Sea",
    description:
      "Complex logistics and crew rotation support for offshore energy installation during critical operational phase.",
    outcome: "Zero downtime achieved",
    image: MEDIA.images.platformSupport,
    href: "/missions/offshore-platform",
  },
  {
    id: "environmental-survey",
    title: "Marine Environmental Survey",
    type: "Environmental",
    environment: "Coastal / Open Sea",
    location: "Pacific Ocean",
    description:
      "Comprehensive environmental monitoring and data collection mission supporting marine conservation research.",
    outcome: "Critical data collected",
    image: MEDIA.images.environmentalSurvey,
    href: "/missions/environmental-survey",
  },
];
