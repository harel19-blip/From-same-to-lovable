/**
 * Capabilities Data
 * Content for the core capabilities/services section
 */

import { Ship, LifeBuoy, TreePine, Cpu, Users } from "lucide-react";
import type { LucideIcon } from "lucide-react";

export interface Capability {
  id: string;
  icon: LucideIcon;
  titleKey: string;
  descriptionKey: string;
  href: string;
}

export const capabilities: Capability[] = [
  {
    id: "maritime",
    icon: Ship,
    titleKey: "capabilities.maritime.title",
    descriptionKey: "capabilities.maritime.description",
    href: "/services#maritime",
  },
  {
    id: "rescue",
    icon: LifeBuoy,
    titleKey: "capabilities.rescue.title",
    descriptionKey: "capabilities.rescue.description",
    href: "/services#rescue",
  },
  {
    id: "environmental",
    icon: TreePine,
    titleKey: "capabilities.environmental.title",
    descriptionKey: "capabilities.environmental.description",
    href: "/services#environmental",
  },
  {
    id: "technology",
    icon: Cpu,
    titleKey: "capabilities.technology.title",
    descriptionKey: "capabilities.technology.description",
    href: "/services#technology",
  },
  {
    id: "crew",
    icon: Users,
    titleKey: "capabilities.crew.title",
    descriptionKey: "capabilities.crew.description",
    href: "/services#crew",
  },
];
