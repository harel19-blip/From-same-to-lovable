/**
 * Data Index
 * Central export point for all content data
 */

// Navigation
export { mainNavigation, footerLinks } from "./navigation";
export type { NavItem, NavSubmenuItem } from "./navigation";

// Content Data
export { capabilities } from "./capabilities";
export type { Capability } from "./capabilities";

export { sectors } from "./sectors";
export type { Sector } from "./sectors";

export { featuredMissions } from "./missions";
export type { Mission } from "./missions";

export { newsArticles, newsCategories, featuredInsights } from "./insights";
export type { NewsArticle } from "./insights";

export { approachSteps } from "./approach";
export type { ApproachStep } from "./approach";
