/**
 * Sectors Data
 * Content for the sectors/industries section
 */

import { MEDIA } from "@/lib/constants";

export interface Sector {
  id: string;
  titleKey: string;
  descriptionKey: string;
  image: string;
  href: string;
}

export const sectors: Sector[] = [
  {
    id: "offshore",
    titleKey: "sectors.offshore.title",
    descriptionKey: "sectors.offshore.description",
    image: MEDIA.images.offshore,
    href: "/sectors#offshore",
  },
  {
    id: "environmental",
    titleKey: "sectors.environmental.title",
    descriptionKey: "sectors.environmental.description",
    image: MEDIA.images.environmental,
    href: "/sectors#environmental",
  },
  {
    id: "rescue",
    titleKey: "sectors.rescue.title",
    descriptionKey: "sectors.rescue.description",
    image: MEDIA.images.rescue,
    href: "/sectors#rescue",
  },
  {
    id: "research",
    titleKey: "sectors.research.title",
    descriptionKey: "sectors.research.description",
    image: MEDIA.images.research,
    href: "/sectors#research",
  },
];
