/**
 * SouliSea Brand Constants
 * Centralized configuration for colors, assets, and external resources
 */

// ============================================================================
// BRAND COLORS
// ============================================================================
export const COLORS = {
  // Primary Navy - Authority & Trust
  navy: {
    900: "#0f172a",
    800: "#1e293b",
    700: "#334155",
  },
  // Accent Blue - Professional & Maritime
  blue: {
    primary: "#1a6fc9",
    hover: "#1558a8",
  },
  // Neutral Slate
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
  },
  // White
  white: "#ffffff",
} as const;

// ============================================================================
// BRAND ASSETS
// ============================================================================
export const ASSETS = {
  logo: "/images/logo.png",
  founder: "/images/founder.jpg",
} as const;

// ============================================================================
// EXTERNAL LINKS
// ============================================================================
export const EXTERNAL_LINKS = {
  linkedin: "https://www.linkedin.com/in/%D7%94%D7%A8%D7%90%D7%9C-%D7%A4%D7%99%D7%A9%D7%9E%D7%9F-1b023b394/",
  email: "contact@soulisea.com",
} as const;

// ============================================================================
// MEDIA ASSETS
// ============================================================================
export const MEDIA = {
  heroVideo: "https://cdn.pixabay.com/video/2020/09/09/49604-458734126_large.mp4",
  images: {
    // Sectors section
    offshore: "https://images.unsplash.com/photo-1589519160732-57fc498494f8?w=1200&q=80",
    environmental: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=1200&q=80",
    rescue: "https://images.unsplash.com/photo-1580674285054-bed31e145f59?w=1200&q=80",
    research: "https://images.unsplash.com/photo-1516594915697-87eb3b4c14ea?w=1200&q=80",
    // Featured missions
    deepSeaRescue: "https://images.unsplash.com/photo-1580674285054-bed31e145f59?w=800&q=80",
    platformSupport: "https://images.unsplash.com/photo-1589519160732-57fc498494f8?w=800&q=80",
    environmentalSurvey: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=800&q=80",
    // News/Insights
    arctic: "https://images.unsplash.com/photo-1483728642387-6c3bdd6c93e5?w=800&q=80",
    sarex: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=800&q=80",
    polar: "https://images.unsplash.com/photo-1516594915697-87eb3b4c14ea?w=800&q=80",
  },
} as const;

// ============================================================================
// NAVIGATION STRUCTURE
// ============================================================================
export const ROUTES = {
  home: "/",
  about: "/about",
  services: "/services",
  missions: "/missions",
  sectors: "/sectors",
  insights: "/insights",
  workWithUs: "/work-with-us",
  contact: "/contact",
  privacy: "/privacy",
  terms: "/terms",
  cookies: "/cookies",
} as const;

// ============================================================================
// COMPANY INFO
// ============================================================================
export const COMPANY = {
  name: "SouliSea",
  tagline: "Where Soul Meets Sea",
  founder: {
    name: "Harel Fishman",
    role: "Founder & CEO",
    yearsExperience: "15+",
  },
} as const;
