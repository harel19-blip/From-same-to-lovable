"use client";

/**
 * HeroSection Component
 * Full-viewport hero with video background
 * Main landing section for the homepage
 */

import Link from "next/link";
import { useTranslations } from "next-intl";
import { Button } from "@/components/ui/button";
import { ChevronDown } from "lucide-react";
import { MEDIA } from "@/lib/constants";

export function HeroSection() {
  const t = useTranslations();

  return (
    <section
      className="relative min-h-screen flex items-center -mt-16 lg:-mt-20 overflow-hidden"
      aria-labelledby="hero-title"
    >
      {/* Video Background */}
      <video
        autoPlay
        loop
        muted
        playsInline
        className="absolute inset-0 w-full h-full object-cover"
        aria-hidden="true"
      >
        <source
          src={MEDIA.heroVideo}
          type="video/mp4"
        />
      </video>

      {/* Gradient overlay for text readability */}
      <div
        className="absolute inset-0 bg-gradient-to-r from-[#0f172a]/95 via-[#0f172a]/85 to-[#0f172a]/70"
        aria-hidden="true"
      />

      {/* Wave pattern overlay */}
      <div className="absolute inset-0 opacity-10" aria-hidden="true">
        <svg className="w-full h-full" viewBox="0 0 1440 900" preserveAspectRatio="none">
          <path
            d="M0,450 C200,350 400,550 600,450 C800,350 1000,550 1200,450 C1400,350 1440,450 1440,450 L1440,900 L0,900 Z"
            fill="currentColor"
            className="text-white/20"
          />
          <path
            d="M0,500 C200,400 400,600 600,500 C800,400 1000,600 1200,500 C1400,400 1440,500 1440,500 L1440,900 L0,900 Z"
            fill="currentColor"
            className="text-white/10"
          />
        </svg>
      </div>

      {/* Content */}
      <div className="relative z-10 container-wide py-20 lg:py-32">
        <div className="max-w-3xl">
          {/* Accent line */}
          <div className="w-16 h-1 bg-[#1a6fc9] mb-8" aria-hidden="true" />

          {/* Main heading */}
          <h1 id="hero-title" className="text-white mb-6">
            <span className="block">{t("hero.title1")}</span>
            <span className="block text-slate-300">{t("hero.title2")}</span>
          </h1>

          {/* Subheading */}
          <p className="text-lg md:text-xl text-slate-300 leading-relaxed mb-10 max-w-2xl">
            {t("hero.subtitle")}
          </p>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Button
              asChild
              size="lg"
              className="bg-white text-[#0f172a] hover:bg-slate-100 px-8"
            >
              <Link href="/services">{t("hero.cta1")}</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white/30 text-white hover:bg-white/10 px-8"
            >
              <Link href="/work-with-us">{t("hero.cta2")}</Link>
            </Button>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center text-white/50 animate-bounce"
        aria-hidden="true"
      >
        <ChevronDown className="w-6 h-6" />
      </div>
    </section>
  );
}
