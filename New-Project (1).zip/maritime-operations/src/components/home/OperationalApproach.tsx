"use client";

/**
 * OperationalApproach Section
 * Displays the 4-step operational methodology
 * Uses shared data and maintains consistent styling
 */

import { useTranslations } from "next-intl";
import { approachSteps } from "@/data";

export function OperationalApproach() {
  const t = useTranslations();

  return (
    <section
      className="section-padding bg-white"
      aria-labelledby="approach-title"
    >
      <div className="container-wide">
        {/* Section Header */}
        <header className="text-center mb-16">
          <div className="accent-line-center" aria-hidden="true" />
          <h2 id="approach-title" className="text-navy mb-4">
            {t("approach.title")}
          </h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            {t("approach.subtitle")}
          </p>
        </header>

        {/* Steps Grid */}
        <div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
          role="list"
        >
          {approachSteps.map((step, index) => (
            <article
              key={step.number}
              className="relative"
              role="listitem"
            >
              {/* Connector line (hidden on mobile and last item) */}
              {index < approachSteps.length - 1 && (
                <div
                  className="hidden lg:block absolute top-12 left-[60%] w-full h-[1px] bg-slate-200"
                  aria-hidden="true"
                />
              )}

              <div className="relative bg-slate-50 rounded-lg p-8 hover:bg-slate-100 transition-colors">
                {/* Number badge */}
                <div
                  className="absolute -top-3 -left-3 w-10 h-10 bg-navy rounded-full flex items-center justify-center text-white text-sm font-bold"
                  aria-hidden="true"
                >
                  {step.number}
                </div>

                {/* Icon */}
                <div className="flex items-center justify-center w-16 h-16 bg-white rounded-lg shadow-sm mb-6">
                  <step.icon className="w-8 h-8 text-navy" aria-hidden="true" />
                </div>

                {/* Content */}
                <h3 className="text-lg font-semibold text-navy mb-3">
                  {t(step.titleKey)}
                </h3>
                <p className="text-sm text-slate-600 leading-relaxed">
                  {t(step.descriptionKey)}
                </p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
