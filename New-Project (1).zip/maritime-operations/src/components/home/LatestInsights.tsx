"use client";

/**
 * LatestInsights Component
 * Displays featured news articles on the homepage
 * Uses shared data and maintains consistent styling
 */

import Link from "next/link";
import Image from "next/image";
import { useTranslations } from "next-intl";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, ChevronRight, ExternalLink } from "lucide-react";
import { featuredInsights } from "@/data";

export function LatestInsights() {
  const t = useTranslations();

  return (
    <section
      className="section-padding bg-white"
      aria-labelledby="insights-title"
    >
      <div className="container-wide">
        {/* Section Header */}
        <header className="flex flex-col md:flex-row md:items-end md:justify-between mb-12">
          <div className="max-w-2xl mb-6 md:mb-0">
            <div className="accent-line" aria-hidden="true" />
            <h2 id="insights-title" className="text-navy mb-4">
              Industry News & Insights
            </h2>
            <p className="text-lg text-slate-600">
              Stay informed on the latest maritime developments, safety innovations,
              and industry trends shaping our operations.
            </p>
          </div>
          <Button
            asChild
            variant="outline"
            className="border-navy text-navy hover:bg-navy hover:text-white self-start md:self-auto"
          >
            <Link href="/insights">
              View all insights
              <ChevronRight className="w-4 h-4 ms-2" aria-hidden="true" />
            </Link>
          </Button>
        </header>

        {/* Insights Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8" role="list">
          {featuredInsights.map((insight) => (
            <Card
              key={insight.id}
              className="group bg-slate-50 border-slate-200 hover:shadow-lg transition-all duration-300 overflow-hidden"
              role="listitem"
            >
              {/* Image */}
              <div className="relative h-48">
                <Image
                  src={insight.image}
                  alt=""
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-300"
                  aria-hidden="true"
                />
                <div
                  className="absolute inset-0 bg-gradient-to-t from-navy/60 to-transparent"
                  aria-hidden="true"
                />
                <Badge
                  variant="secondary"
                  className="absolute top-4 start-4 bg-white/90 text-navy text-xs"
                >
                  {insight.category}
                </Badge>
              </div>

              <CardContent className="p-6">
                {/* Date */}
                <div className="flex items-center text-sm text-slate-500 mb-3">
                  <Calendar className="w-4 h-4 me-1.5" aria-hidden="true" />
                  <time>{insight.date}</time>
                </div>

                {/* Title */}
                <h3 className="text-lg font-semibold text-navy mb-3 group-hover:text-slate-700 transition-colors line-clamp-2">
                  {insight.title}
                </h3>

                {/* Excerpt */}
                <p className="text-sm text-slate-600 leading-relaxed mb-4 line-clamp-3">
                  {insight.excerpt}
                </p>

                {/* Link */}
                <a
                  href={insight.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center text-sm font-medium text-navy hover:text-slate-700 transition-colors"
                >
                  Read More
                  <ExternalLink className="w-4 h-4 ms-1" aria-hidden="true" />
                </a>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
