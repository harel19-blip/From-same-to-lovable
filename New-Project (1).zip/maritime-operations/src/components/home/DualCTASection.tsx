"use client";

/**
 * DualCTASection Component
 * Dual call-to-action section for contact and recruitment
 * Uses shared CTASection component for consistent styling
 */

import { useTranslations } from "next-intl";
import { Briefcase, Users } from "lucide-react";
import { CTASection } from "@/components/shared";

export function DualCTASection() {
  const t = useTranslations();

  return (
    <section className="bg-white" aria-label="Get in touch">
      <div className="grid lg:grid-cols-2">
        {/* Client CTA */}
        <CTASection
          icon={Briefcase}
          title={t("cta.partner.title")}
          description={t("cta.partner.description")}
          primaryButton={{
            label: t("cta.partner.button"),
            href: "/contact",
          }}
          note={t("cta.partner.note")}
          variant="dark"
        />

        {/* Recruitment CTA - PROMINENT */}
        <CTASection
          icon={Users}
          title={t("cta.join.title")}
          description={t("cta.join.description")}
          primaryButton={{
            label: t("cta.join.button"),
            href: "/work-with-us",
          }}
          note={t("cta.join.note")}
          variant="gradient"
        />
      </div>
    </section>
  );
}
