/**
 * StatCard Component
 * Displays a statistic with an icon, value, and label
 * Used in MissionStatement and other statistics sections
 */

import { cn } from "@/lib/utils";
import type { LucideIcon } from "lucide-react";

interface StatCardProps {
  icon: LucideIcon;
  value: string;
  label: string;
  className?: string;
}

export function StatCard({ icon: Icon, value, label, className }: StatCardProps) {
  return (
    <div className={cn("text-center", className)}>
      {/* Icon Container */}
      <div className="inline-flex items-center justify-center w-14 h-14 bg-[#1a6fc9]/10 rounded-lg mb-4">
        <Icon className="w-7 h-7 text-[#1a6fc9]" aria-hidden="true" />
      </div>

      {/* Value */}
      <div className="text-3xl md:text-4xl font-semibold text-[#0f172a] mb-2">
        {value}
      </div>

      {/* Label */}
      <div className="text-sm text-slate-600 uppercase tracking-wider">
        {label}
      </div>
    </div>
  );
}
