/**
 * SectionHeader Component
 * Reusable header pattern for page sections
 * Supports centered and left-aligned variants
 */

import { cn } from "@/lib/utils";

interface SectionHeaderProps {
  title: string;
  subtitle?: string;
  centered?: boolean;
  accentColor?: "blue" | "stone";
  className?: string;
  titleClassName?: string;
  subtitleClassName?: string;
}

export function SectionHeader({
  title,
  subtitle,
  centered = false,
  accentColor = "blue",
  className,
  titleClassName,
  subtitleClassName,
}: SectionHeaderProps) {
  const accentColors = {
    blue: "bg-[#1a6fc9]",
    stone: "bg-[hsl(30,6%,63%)]",
  };

  return (
    <div
      className={cn(
        "mb-12",
        centered && "text-center",
        !centered && "max-w-2xl",
        className
      )}
    >
      {/* Accent Line */}
      <div
        className={cn(
          "w-16 h-1 mb-6",
          accentColors[accentColor],
          centered && "mx-auto"
        )}
        aria-hidden="true"
      />

      {/* Title */}
      <h2
        className={cn(
          "text-[#0f172a] mb-4",
          titleClassName
        )}
      >
        {title}
      </h2>

      {/* Subtitle */}
      {subtitle && (
        <p
          className={cn(
            "text-lg text-slate-600",
            centered && "max-w-2xl mx-auto",
            subtitleClassName
          )}
        >
          {subtitle}
        </p>
      )}
    </div>
  );
}
