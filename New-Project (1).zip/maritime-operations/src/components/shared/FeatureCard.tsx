/**
 * FeatureCard Component
 * Displays a feature/capability with icon, title, description, and optional link
 * Used in CapabilitiesSection and expertise sections
 */

import Link from "next/link";
import { cn } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";
import { ChevronRight } from "lucide-react";
import type { LucideIcon } from "lucide-react";

interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  href?: string;
  linkText?: string;
  className?: string;
  variant?: "default" | "dark" | "minimal";
}

export function FeatureCard({
  icon: Icon,
  title,
  description,
  href,
  linkText = "Learn More",
  className,
  variant = "default",
}: FeatureCardProps) {
  const variants = {
    default: {
      card: "bg-white border-slate-200 hover:border-slate-300 hover:shadow-lg",
      icon: "bg-[#1a6fc9]/10 group-hover:bg-[#1a6fc9]",
      iconColor: "text-[#1a6fc9] group-hover:text-white",
      title: "text-[#0f172a]",
      description: "text-slate-600",
      link: "text-[#1a6fc9] hover:text-[#1558a8]",
    },
    dark: {
      card: "bg-white/5 border-white/10",
      icon: "bg-[#1a6fc9]/20",
      iconColor: "text-[#1a6fc9]",
      title: "text-white",
      description: "text-slate-400",
      link: "text-[#1a6fc9] hover:text-white",
    },
    minimal: {
      card: "bg-slate-50 border-0",
      icon: "bg-[#1a6fc9]/10",
      iconColor: "text-[#1a6fc9]",
      title: "text-[#0f172a]",
      description: "text-slate-600",
      link: "text-[#1a6fc9] hover:text-[#1558a8]",
    },
  };

  const styles = variants[variant];

  return (
    <Card
      className={cn(
        "group transition-all duration-300",
        styles.card,
        className
      )}
    >
      <CardContent className="p-8">
        {/* Icon */}
        <div
          className={cn(
            "flex items-center justify-center w-14 h-14 rounded-lg mb-6 group-hover:scale-105 transition-all duration-300",
            styles.icon
          )}
        >
          <Icon
            className={cn("w-7 h-7 transition-colors", styles.iconColor)}
            aria-hidden="true"
          />
        </div>

        {/* Title */}
        <h3 className={cn("text-xl font-semibold mb-3", styles.title)}>
          {title}
        </h3>

        {/* Description */}
        <p className={cn("mb-6 leading-relaxed", styles.description)}>
          {description}
        </p>

        {/* Link */}
        {href && (
          <Link
            href={href}
            className={cn(
              "inline-flex items-center text-sm font-medium transition-colors",
              styles.link
            )}
          >
            {linkText}
            <ChevronRight className="w-4 h-4 ms-1 group-hover:translate-x-1 rtl:group-hover:-translate-x-1 transition-transform" />
          </Link>
        )}
      </CardContent>
    </Card>
  );
}
