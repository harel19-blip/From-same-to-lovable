/**
 * PageHero Component
 * Reusable hero section for interior pages
 * Consistent gradient background with title and subtitle
 */

import { cn } from "@/lib/utils";

interface PageHeroProps {
  title: string;
  subtitle?: string;
  className?: string;
}

export function PageHero({ title, subtitle, className }: PageHeroProps) {
  return (
    <section
      className={cn(
        "relative bg-[#0f172a] py-20 lg:py-28",
        className
      )}
    >
      {/* Background Gradient */}
      <div
        className="absolute inset-0 bg-gradient-to-br from-[#0f172a] via-[#1e3a5f] to-[#1a6fc9] opacity-90"
        aria-hidden="true"
      />

      {/* Content Container */}
      <div className="container-wide relative">
        <div className="max-w-3xl">
          {/* Accent Line */}
          <div
            className="w-16 h-1 bg-[#1a6fc9] mb-8"
            aria-hidden="true"
          />

          {/* Title */}
          <h1 className="text-white mb-6">{title}</h1>

          {/* Subtitle */}
          {subtitle && (
            <p className="text-xl text-slate-300 leading-relaxed">
              {subtitle}
            </p>
          )}
        </div>
      </div>
    </section>
  );
}
