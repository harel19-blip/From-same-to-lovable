/**
 * CTASection Component
 * Reusable call-to-action section with customizable styling
 * Supports primary and secondary button variants
 */

import Link from "next/link";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import type { LucideIcon } from "lucide-react";

interface CTAButton {
  label: string;
  href: string;
  variant?: "primary" | "secondary" | "outline";
}

interface CTASectionProps {
  icon?: LucideIcon;
  title: string;
  description: string;
  primaryButton: CTAButton;
  secondaryButton?: CTAButton;
  note?: string;
  variant?: "dark" | "light" | "gradient";
  className?: string;
}

export function CTASection({
  icon: Icon,
  title,
  description,
  primaryButton,
  secondaryButton,
  note,
  variant = "dark",
  className,
}: CTASectionProps) {
  const variants = {
    dark: {
      bg: "bg-[#0f172a]",
      iconBg: "bg-white/10",
      iconColor: "text-white",
      title: "text-white",
      description: "text-slate-300",
      note: "text-slate-400",
      primaryBtn: "bg-white text-[#0f172a] hover:bg-slate-100",
      outlineBtn: "border-white/30 text-white hover:bg-white/10",
    },
    gradient: {
      bg: "bg-gradient-to-br from-[#1a6fc9] to-[#1558a8]",
      iconBg: "bg-white/20",
      iconColor: "text-white",
      title: "text-white",
      description: "text-white/90",
      note: "text-white/80",
      primaryBtn: "bg-white text-[#1a6fc9] hover:bg-slate-100 font-semibold",
      outlineBtn: "border-white/30 text-white hover:bg-white/10",
    },
    light: {
      bg: "bg-white",
      iconBg: "bg-[#1a6fc9]/10",
      iconColor: "text-[#1a6fc9]",
      title: "text-[#0f172a]",
      description: "text-slate-600",
      note: "text-slate-500",
      primaryBtn: "bg-[#1a6fc9] text-white hover:bg-[#1558a8]",
      outlineBtn: "border-[#0f172a] text-[#0f172a] hover:bg-[#0f172a] hover:text-white",
    },
  };

  const styles = variants[variant];

  return (
    <div className={cn("p-12 lg:p-16 xl:p-20", styles.bg, className)}>
      <div className="relative">
        {/* Icon */}
        {Icon && (
          <div
            className={cn(
              "inline-flex items-center justify-center w-14 h-14 rounded-lg mb-6",
              styles.iconBg
            )}
          >
            <Icon className={cn("w-7 h-7", styles.iconColor)} aria-hidden="true" />
          </div>
        )}

        {/* Title */}
        <h3 className={cn("text-2xl lg:text-3xl font-semibold mb-4", styles.title)}>
          {title}
        </h3>

        {/* Description */}
        <p className={cn("leading-relaxed mb-8 max-w-md", styles.description)}>
          {description}
        </p>

        {/* Buttons */}
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <Button
              asChild
              size="lg"
              className={cn("w-full sm:w-auto", styles.primaryBtn)}
            >
              <Link href={primaryButton.href}>
                {primaryButton.label}
                <ArrowRight className="w-4 h-4 ms-2" aria-hidden="true" />
              </Link>
            </Button>

            {secondaryButton && (
              <Button
                asChild
                size="lg"
                variant="outline"
                className={cn("w-full sm:w-auto", styles.outlineBtn)}
              >
                <Link href={secondaryButton.href}>
                  {secondaryButton.label}
                </Link>
              </Button>
            )}
          </div>

          {/* Note */}
          {note && <p className={cn("text-sm", styles.note)}>{note}</p>}
        </div>
      </div>
    </div>
  );
}
