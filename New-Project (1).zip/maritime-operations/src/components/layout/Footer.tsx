"use client";

import Link from "next/link";
import Image from "next/image";
import { useTranslations } from "next-intl";
import { Linkedin, Mail, ChevronUp, Globe } from "lucide-react";

export function Footer() {
  const t = useTranslations();

  const currentLocale = typeof document !== "undefined"
    ? (document.cookie.match(/locale=([^;]+)/)?.[1] as "en" | "he") || "en"
    : "en";

  const toggleLanguage = () => {
    const newLocale = currentLocale === "en" ? "he" : "en";
    document.cookie = `locale=${newLocale};path=/;max-age=31536000`;
    window.location.reload();
  };

  const handleScrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const footerLinks = {
    company: [
      { name: t("nav.about"), href: "/about" },
      { name: t("nav.services"), href: "/services" },
      { name: t("nav.missions"), href: "/missions" },
      { name: t("nav.sectors"), href: "/sectors" },
    ],
    careers: [
      { name: t("nav.workWithUs"), href: "/work-with-us" },
    ],
    resources: [
      { name: t("nav.insights"), href: "/insights" },
      { name: t("nav.contact"), href: "/contact" },
    ],
    legal: [
      { name: t("footer.privacy"), href: "/privacy" },
      { name: t("footer.terms"), href: "/terms" },
      { name: t("footer.cookies"), href: "/cookies" },
    ],
  };

  return (
    <footer className="bg-[#0f172a] text-white">
      {/* Main Footer Content */}
      <div className="container-wide section-padding">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 lg:gap-8">
          {/* Brand Column */}
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center space-x-3 rtl:space-x-reverse mb-6">
              <div className="w-10 h-10 relative">
                <Image
                  src="/images/logo.png"
                  alt="SouliSea"
                  fill
                  className="object-contain brightness-0 invert"
                />
              </div>
              <div>
                <span className="text-lg font-semibold">SouliSea</span>
              </div>
            </Link>
            <p className="text-slate-400 text-sm leading-relaxed mb-6 max-w-sm">
              {t("footer.description")}
            </p>

            {/* Contact Info */}
            <div className="space-y-3">
              <a
                href="mailto:contact@soulisea.com"
                className="flex items-center space-x-3 rtl:space-x-reverse text-sm text-slate-400 hover:text-white transition-colors"
              >
                <Mail className="w-4 h-4" />
                <span>contact@soulisea.com</span>
              </a>
            </div>
          </div>

          {/* Company Links */}
          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider mb-4 text-white">
              {t("footer.company")}
            </h4>
            <ul className="space-y-2.5">
              {footerLinks.company.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-sm text-slate-400 hover:text-white transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Careers Links */}
          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider mb-4 text-white">
              {t("footer.careers")}
            </h4>
            <ul className="space-y-2.5">
              {footerLinks.careers.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-sm text-slate-400 hover:text-white transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider mb-4 text-white">
              {t("footer.resources")}
            </h4>
            <ul className="space-y-2.5">
              {footerLinks.resources.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-sm text-slate-400 hover:text-white transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>

            {/* Social Links */}
            <div className="mt-6">
              <h4 className="text-sm font-semibold uppercase tracking-wider mb-3 text-white">
                {t("footer.stayConnected")}
              </h4>
              <a
                href="https://www.linkedin.com/in/%D7%94%D7%A8%D7%90%D7%9C-%D7%A4%D7%99%D7%A9%D7%9E%D7%9F-1b023b394/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center space-x-2 rtl:space-x-reverse text-sm text-slate-400 hover:text-white transition-colors"
              >
                <Linkedin className="w-5 h-5" />
                <span>LinkedIn</span>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Back to Top */}
      <div className="bg-[#1e293b]">
        <div className="container-wide">
          <button
            onClick={handleScrollToTop}
            className="w-full py-4 flex items-center justify-center space-x-2 rtl:space-x-reverse text-sm text-slate-400 hover:text-white transition-colors"
          >
            <ChevronUp className="w-5 h-5" />
            <span>{t("common.backToTop")}</span>
          </button>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/10">
        <div className="container-wide py-6">
          <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
            {/* Copyright */}
            <p className="text-sm text-slate-500">
              {new Date().getFullYear()} {t("footer.copyright")}
            </p>

            {/* Legal Links */}
            <div className="flex flex-wrap items-center justify-center gap-4 md:gap-6">
              {footerLinks.legal.map((link) => (
                <Link
                  key={link.name}
                  href={link.href}
                  className="text-sm text-slate-500 hover:text-white transition-colors"
                >
                  {link.name}
                </Link>
              ))}
            </div>

            {/* Language Switcher */}
            <button
              onClick={toggleLanguage}
              className="flex items-center space-x-2 rtl:space-x-reverse text-sm text-slate-500 hover:text-white transition-colors"
            >
              <Globe className="w-4 h-4" />
              <span>{currentLocale === "en" ? "EN / עב" : "EN / עב"}</span>
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
