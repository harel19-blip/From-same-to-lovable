"use client";

import Link from "next/link";
import Image from "next/image";
import { useState, useTransition } from "react";
import { useTranslations } from "next-intl";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";
import { Menu, Globe, ChevronRight, X } from "lucide-react";

export function Header() {
  const t = useTranslations();
  const [isOpen, setIsOpen] = useState(false);
  const [isPending, startTransition] = useTransition();

  const currentLocale = typeof document !== "undefined"
    ? (document.cookie.match(/locale=([^;]+)/)?.[1] as "en" | "he") || "en"
    : "en";

  const toggleLanguage = () => {
    const newLocale = currentLocale === "en" ? "he" : "en";
    startTransition(() => {
      document.cookie = `locale=${newLocale};path=/;max-age=31536000`;
      window.location.reload();
    });
  };

  const navigation = {
    main: [
      { name: t("nav.home"), href: "/" },
      {
        name: t("nav.about"),
        href: "/about",
        submenu: [
          { name: t("nav.aboutCompany"), href: "/about", description: t("about.overviewTitle") },
          { name: t("nav.aboutFounder"), href: "/about#founder", description: t("founder.role") },
          { name: t("nav.aboutValues"), href: "/about#values", description: t("about.valuesTitle") },
        ],
      },
      {
        name: t("nav.services"),
        href: "/services",
        submenu: [
          { name: t("nav.maritimeOps"), href: "/services#maritime", description: t("capabilities.maritime.title") },
          { name: t("nav.rescue"), href: "/services#rescue", description: t("capabilities.rescue.title") },
          { name: t("nav.environmental"), href: "/services#environmental", description: t("capabilities.environmental.title") },
          { name: t("nav.technology"), href: "/services#technology", description: t("capabilities.technology.title") },
          { name: t("nav.crewAssembly"), href: "/services#crew", description: t("capabilities.crew.title") },
        ],
      },
      { name: t("nav.missions"), href: "/missions" },
      {
        name: t("nav.sectors"),
        href: "/sectors",
        submenu: [
          { name: t("nav.offshore"), href: "/sectors#offshore", description: t("sectors.offshore.title") },
          { name: t("nav.environmentalSector"), href: "/sectors#environmental", description: t("sectors.environmental.title") },
          { name: t("nav.rescueSector"), href: "/sectors#rescue", description: t("sectors.rescue.title") },
          { name: t("nav.research"), href: "/sectors#research", description: t("sectors.research.title") },
        ],
      },
      { name: t("nav.insights"), href: "/insights" },
      { name: t("nav.workWithUs"), href: "/work-with-us" },
    ],
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm border-b border-slate-200">
      <div className="container-wide">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-3 rtl:space-x-reverse">
            <div className="w-10 h-10 relative">
              <Image
                src="/images/logo.png"
                alt="SouliSea"
                fill
                className="object-contain"
                priority
              />
            </div>
            <div className="hidden sm:block">
              <span className="text-lg font-semibold text-[#1a6fc9] tracking-tight">SouliSea</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <NavigationMenu className="hidden lg:flex">
            <NavigationMenuList className="space-x-1 rtl:space-x-reverse">
              {navigation.main.map((item) => (
                <NavigationMenuItem key={item.name}>
                  {item.submenu ? (
                    <>
                      <NavigationMenuTrigger className="text-sm font-medium text-slate-700 hover:text-[#1a6fc9] bg-transparent hover:bg-slate-50">
                        {item.name}
                      </NavigationMenuTrigger>
                      <NavigationMenuContent>
                        <ul className="grid w-[400px] gap-1 p-4">
                          {item.submenu.map((subItem) => (
                            <li key={subItem.name}>
                              <NavigationMenuLink asChild>
                                <Link
                                  href={subItem.href}
                                  className="block select-none rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-slate-50 focus:bg-slate-50"
                                >
                                  <div className="text-sm font-medium text-[#1a6fc9] mb-1">
                                    {subItem.name}
                                  </div>
                                  <p className="text-xs text-slate-500 leading-relaxed">
                                    {subItem.description}
                                  </p>
                                </Link>
                              </NavigationMenuLink>
                            </li>
                          ))}
                        </ul>
                      </NavigationMenuContent>
                    </>
                  ) : (
                    <Link
                      href={item.href}
                      className="inline-flex items-center justify-center px-4 py-2 text-sm font-medium text-slate-700 hover:text-[#1a6fc9] hover:bg-slate-50 rounded-md transition-colors"
                    >
                      {item.name}
                    </Link>
                  )}
                </NavigationMenuItem>
              ))}
            </NavigationMenuList>
          </NavigationMenu>

          {/* Right Side Actions */}
          <div className="flex items-center space-x-3 rtl:space-x-reverse">
            {/* Language Switcher */}
            <button
              onClick={toggleLanguage}
              disabled={isPending}
              className="hidden sm:flex items-center space-x-1.5 rtl:space-x-reverse px-3 py-1.5 text-sm text-slate-600 hover:text-[#1a6fc9] transition-colors rounded-md hover:bg-slate-50 disabled:opacity-50"
              aria-label="Switch language"
            >
              <Globe className="w-4 h-4" />
              <span className="font-medium">{currentLocale === "en" ? "HE" : "EN"}</span>
            </button>

            {/* Contact CTA */}
            <Button
              asChild
              className="hidden md:inline-flex bg-[#1a6fc9] hover:bg-[#1558a8] text-white px-5"
            >
              <Link href="/contact">{t("common.contactUs")}</Link>
            </Button>

            {/* Mobile Menu Toggle */}
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="lg:hidden"
                  aria-label="Open menu"
                >
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-full sm:w-[400px] p-0">
                <SheetTitle className="sr-only">Navigation Menu</SheetTitle>
                <div className="flex flex-col h-full">
                  {/* Mobile Header */}
                  <div className="flex items-center justify-between px-6 py-4 border-b">
                    <span className="text-lg font-semibold text-[#1a6fc9]">Menu</span>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setIsOpen(false)}
                      aria-label="Close menu"
                    >
                      <X className="h-5 w-5" />
                    </Button>
                  </div>

                  {/* Mobile Navigation */}
                  <nav className="flex-1 overflow-y-auto py-4">
                    {navigation.main.map((item) => (
                      <div key={item.name} className="px-6">
                        <Link
                          href={item.href}
                          onClick={() => setIsOpen(false)}
                          className="flex items-center justify-between py-3 text-base font-medium text-slate-800 hover:text-[#1a6fc9] border-b border-slate-100"
                        >
                          {item.name}
                          <ChevronRight className="w-4 h-4 text-slate-400 rtl:rotate-180" />
                        </Link>
                        {item.submenu && (
                          <div className="ps-4 py-2 space-y-1">
                            {item.submenu.map((subItem) => (
                              <Link
                                key={subItem.name}
                                href={subItem.href}
                                onClick={() => setIsOpen(false)}
                                className="block py-2 text-sm text-slate-600 hover:text-[#1a6fc9]"
                              >
                                {subItem.name}
                              </Link>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </nav>

                  {/* Mobile Footer */}
                  <div className="px-6 py-6 border-t bg-slate-50">
                    <Button
                      asChild
                      className="w-full bg-[#1a6fc9] hover:bg-[#1558a8] text-white mb-4"
                    >
                      <Link href="/contact" onClick={() => setIsOpen(false)}>
                        {t("common.contactUs")}
                      </Link>
                    </Button>
                    <button
                      onClick={toggleLanguage}
                      disabled={isPending}
                      className="flex items-center justify-center space-x-2 rtl:space-x-reverse w-full py-2 text-sm text-slate-600"
                    >
                      <Globe className="w-4 h-4" />
                      <span>{currentLocale === "en" ? t("common.hebrew") : t("common.english")}</span>
                    </button>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
